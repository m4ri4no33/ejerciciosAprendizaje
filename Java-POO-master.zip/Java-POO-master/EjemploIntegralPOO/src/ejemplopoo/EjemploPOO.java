
package ejemplopoo;

import Service.PersonaService;


public class EjemploPOO {

    public static void main(String[] args) {
       PersonaService ps = new PersonaService();
       ps.crearPersona();
    }
    
}
