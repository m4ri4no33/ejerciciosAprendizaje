
package servicios;

public class VendedorService {
    
}
