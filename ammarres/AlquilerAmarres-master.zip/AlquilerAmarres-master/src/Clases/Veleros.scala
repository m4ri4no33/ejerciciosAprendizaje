package Clases

class Veleros( val matriculaBarco : String, val esloraBarco : Int, val anioFabricacionBarco: Fecha, mastiles : Int) extends Barco(matriculaBarco, esloraBarco, anioFabricacionBarco){
  var nroMastiles = mastiles

}
