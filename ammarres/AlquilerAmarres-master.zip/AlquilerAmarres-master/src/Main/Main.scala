package Main

import GUI._

object Main {

  def main(args: Array[String]): Unit = {
    val aplicacion = new frmAplicacionPrincipal()
    aplicacion.setVisible(true)
  }
}
