/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guia2ejercicio2;

import java.util.Scanner;

/**
 *
 * @author no_de
 */
public class Guia2Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Escribir un programa que pida tu nombre, lo guarde en una variable y lo muestre por pantalla.
        // Inicializo Scanner 
        Scanner leer = new Scanner(System.in);
        String palabra;
        System.out.println("Ingrese su nombre : ");
        palabra = leer.next();
        
        System.out.println("Su nombre es : " + palabra);
        
        
        
        
        
       
        
        
    }
    
}
